package org.koin.sampleapp.view

object Arguments {
    const val ARG_ADDRESS: String = "ARG_ADDRESS"
    const val ARG_WEATHER_DATE = "WEATHER_DATE"
    const val ARG_WEATHER_ITEM_ID: String = "WEATHER_ID"
}