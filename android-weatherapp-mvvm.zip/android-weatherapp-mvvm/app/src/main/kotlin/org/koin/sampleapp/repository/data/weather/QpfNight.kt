package org.koin.sampleapp.repository.data.weather

import com.google.gson.annotations.Expose

class QpfNight {

    /**
     * @return The in
     */
    /**
     * @param in The in
     */
    @Expose
    var `in`: Double? = null
    /**
     * @return The mm
     */
    /**
     * @param mm The mm
     */
    @Expose
    var mm: Int? = null

}
