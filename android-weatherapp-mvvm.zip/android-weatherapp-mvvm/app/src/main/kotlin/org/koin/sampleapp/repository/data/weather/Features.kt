package org.koin.sampleapp.repository.data.weather

import com.google.gson.annotations.Expose

class Features {

    /**
     * @return The forecast
     */
    /**
     * @param forecast The forecast
     */
    @Expose
    var forecast: Int? = null

}